export default function ExplorePage() {
  return <main>ExplorePage</main>;
}
