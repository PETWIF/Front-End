export { default as AlbumPostPage } from './AlbumPostPage';
