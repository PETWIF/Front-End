export default function AlbumPostPage() {
  return <main></main>;
}
