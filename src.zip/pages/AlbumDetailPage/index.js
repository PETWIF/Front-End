export { default as AlbumDetailPage } from './AlbumDetailPage';
