export default function BookmarkPage() {
  return <main>BookmarkPage</main>;
}
