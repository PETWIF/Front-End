export { default as FriendPage } from './FriendPage';
