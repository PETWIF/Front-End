export default function FriendPage() {
  return <main>FriendPage</main>;
}
