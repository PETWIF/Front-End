export { default as AlbumPage } from './AlbumPage';
