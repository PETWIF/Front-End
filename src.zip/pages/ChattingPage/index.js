export { default as ChattingPage } from './ChattingPage';
