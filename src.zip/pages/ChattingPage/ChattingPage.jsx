export default function ChattingPage() {
  return <main>ChattingPage</main>;
}
