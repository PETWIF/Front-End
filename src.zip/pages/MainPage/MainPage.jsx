import React from 'react';
import { 
    MainContainer, 
    Header, 
    SideBar, 
    MainContent, 
    ProfileSection, 
    AlbumThumbnail, 
    Notifications, 
    UserManagement,
    RecommendationSection,
    CommentSection,
    Footer 
} from './MainPage.style';

const MainPage = () => {
    return (
        <MainContainer>
            <Header>
                <UserManagement>사용자 관리</UserManagement>
                <Notifications>알림 설정</Notifications>
            </Header>
            <SideBar />
            <MainContent>
                <ProfileSection>
                    <div>프로필</div>
                    <div>고영희러버 님</div>
                    <div>1시간 전</div>
                </ProfileSection>
                <AlbumThumbnail>
                    {/* 앨범 썸네일 이미지 */}
                </AlbumThumbnail>
                <CommentSection>
                    <div>pet_01 님 외 19명이 좋아요를 눌렀어요</div>
                    <div>내 고양이 ‘고영희’과의 첫 추억이 담긴 앨범...</div>
                    <div>사진 잘 보고 갑니다. 귀여워요!</div>
                    <div>고양이가 귀여워요!</div>
                </CommentSection>
            </MainContent>
            <RecommendationSection>
                <div>펫위프 님을 위한 추천</div>
                {/* 추천 컨텐츠 */}
            </RecommendationSection>
            <Footer />
        </MainContainer>
    );
};

export default MainPage;
