import styled from 'styled-components';

export const MainContainer = styled.div`
    position: relative;
    width: 1728px;
    height: 1045px;
    background: #F3F4F6;
`;

export const Header = styled.div`
    position: absolute;
    width: 100%;
    height: 72px;
    top: 0;
    background: #FFFFFF;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    padding-right: 20px;
`;

export const UserManagement = styled.div`
    font-family: 'Noto Sans KR', sans-serif;
    font-size: 18px;
    font-weight: 500;
    margin-right: 20px;
    cursor: pointer;
`;

export const Notifications = styled.div`
    font-family: 'Noto Sans KR', sans-serif;
    font-size: 18px;
    font-weight: 500;
    cursor: pointer;
`;

export const SideBar = styled.div`
    position: absolute;
    width: 520px;
    height: 100%;
    top: 72px;
    right: 0;
    background: #F3F4F6;
`;

export const MainContent = styled.div`
    position: absolute;
    width: 1183px;
    height: 1002px;
    top: 85px;
    left: 25px;
    background: #FFFFFF;
    border-radius: 15px;
`;

export const ProfileSection = styled.div`
    position: absolute;
    top: 314px;
    left: 93px;
    div {
        margin-bottom: 10px;
        font-family: 'Noto Sans KR', sans-serif;
    }
`;

export const AlbumThumbnail = styled.div`
    position: absolute;
    top: 382px;
    left: 88px;
    width: 693px;
    height: 632px;
    background: url(.jpg);
    border-radius: 15px;
`;

export const CommentSection = styled.div`
    position: absolute;
    top: 399px;
    left: 841px;
    div {
        margin-bottom: 10px;
        font-family: 'Noto Sans KR', sans-serif;
        font-size: 16px;
    }
`;

export const RecommendationSection = styled.div`
    position: absolute;
    top: 127px;
    left: 1266px;
    width: 438px;
    height: 499px;
    background: #FFFFFF;
    border-radius: 15px;
`;

export const Footer = styled.div`
    position: absolute;
    width: 100%;
    height: 50px;
    bottom: 0;
    background: #FFFFFF;
`;

