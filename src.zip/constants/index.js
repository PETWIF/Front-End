import { SIDE_MENUS } from './menu.js';

export { SIDE_MENUS };
