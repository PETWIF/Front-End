import * as S from './Profile.style.jsx';

export default function Profile({ src, size }) {
  return <S.Profile src={src} $size={size} />;
}
