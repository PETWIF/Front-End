export { default as RandomFriend } from './RandomFriend';
