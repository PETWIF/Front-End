export { RANDOM_FRIENDS } from './friend.js';
