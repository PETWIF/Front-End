import { Profile } from '../images';

export const RANDOM_FRIENDS = [
  {
    userId: 1,
    name: 'Alice',
    image: Profile,
  },
  {
    userId: 2,
    name: 'Bob',
    image: Profile,
  },
  {
    userId: 3,
    name: 'Cat',
    image: Profile,
  },
  {
    userId: 4,
    name: 'Don',
    image: Profile,
  },
];
