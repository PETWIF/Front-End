export { default as Profile } from './profile.jpeg';
